@extends('layouts.pembeli')

@section('title', 'Riwayat Pesanan')
@section('page-title', 'Riwayat Pesanan')

@section('content')
<style>
    .hist-card { background:white; border-radius:20px; padding:22px; box-shadow:0 2px 12px rgba(0,0,0,0.06); border-left:4px solid #22C55E; transition:all .25s; }
    .hist-card:hover { transform:translateY(-2px); box-shadow:0 8px 24px rgba(0,0,0,0.1); }
    .item-chip { display:inline-flex; align-items:center; gap:6px; background:#F0F4F8; border-radius:99px; padding:5px 12px; font-size:12px; font-weight:600; color:#475569; margin:3px; }
</style>

<div style="max-width:900px;">
    @if($orders->isEmpty())
    <div style="background:white;border-radius:24px;padding:72px;text-align:center;box-shadow:0 2px 12px rgba(0,0,0,0.05);">
        <div style="width:80px;height:80px;background:#F0F4F8;border-radius:24px;display:flex;align-items:center;justify-content:center;font-size:36px;margin:0 auto 16px;">📭</div>
        <h3 style="font-size:20px;font-weight:900;color:#1e293b;margin-bottom:8px;">Belum Ada Riwayat</h3>
        <p style="color:#94A3B8;font-size:14px;margin-bottom:28px;">Pesanan yang sudah selesai akan muncul di sini.</p>
        <a href="{{ route('canteens.shop') }}" style="background:linear-gradient(135deg,#1a3a5c,#2d6a8f);color:white;padding:13px 28px;border-radius:14px;font-weight:800;text-decoration:none;font-size:14px;">Lihat Daftar Kantin</a>
    </div>
    @else
    <p style="color:#94A3B8;font-size:13px;font-weight:600;margin-bottom:20px;">{{ $orders->count() }} pesanan selesai</p>
    <div style="display:flex;flex-direction:column;gap:16px;">
        @foreach($orders as $order)
        @php $items = is_array($order->items) ? $order->items : (json_decode($order->items, true) ?? []); @endphp
        <div class="hist-card">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px;">
                <div>
                    <p style="font-size:16px;font-weight:900;color:#1e293b;font-family:monospace;">{{ $order->order_number }}</p>
                    <p style="font-size:12px;color:#94A3B8;margin-top:3px;">{{ $order->created_at->format('d M Y, H:i') }} · {{ $order->created_at->diffForHumans() }}</p>
                </div>
                <span style="background:#D1FAE5;color:#065F46;font-size:11px;font-weight:800;padding:5px 12px;border-radius:99px;">✅ Selesai</span>
            </div>

            <div style="display:flex;flex-wrap:wrap;margin-bottom:14px;">
                @foreach($items as $item)
                <span class="item-chip">🍽️ {{ $item['name'] }} × {{ $item['qty'] }}</span>
                @endforeach
            </div>

            <div style="display:flex;justify-content:space-between;align-items:center;padding-top:14px;border-top:1px solid #F1F5F9;">
                <div>
                    <p style="font-size:11px;color:#94A3B8;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;">Kantin</p>
                    <p style="font-size:13px;font-weight:700;color:#1e293b;">{{ $order->canteen->name ?? '-' }}</p>
                </div>
                <div style="text-align:right;">
                    <p style="font-size:11px;color:#94A3B8;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;">Total Bayar</p>
                    <p style="font-size:20px;font-weight:900;color:#1a3a5c;">Rp {{ number_format($order->total_amount, 0, ',', '.') }}</p>
                </div>
            </div>
        </div>
        @endforeach
    </div>
    @endif
</div>
@endsection
