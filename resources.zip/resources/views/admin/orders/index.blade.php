@extends('layouts.app')

@section('content')
<div class="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-8 px-4 sm:px-6 lg:px-8">
    <div class="max-w-7xl mx-auto">

        <!-- Header + Tombol Kembali -->
        <div class="mb-8 flex items-center justify-between">
            <div>
                <a href="{{ route('admin.dashboard') }}" class="inline-flex items-center gap-2 text-gray-600 hover:text-[#122C4F] font-bold mb-3 transition">
                    <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
                </a>
                <h1 class="text-4xl font-black text-gray-900 mb-2">📋 Monitoring Pesanan</h1>
                <p class="text-gray-600 font-medium">Pantau semua pesanan dari seluruh kantin Tel-U</p>
            </div>
        </div>

        <!-- Filters -->
        <div class="bg-white rounded-lg shadow-sm p-6 mb-8">
            <form method="GET" class="flex flex-wrap gap-4 items-end">
                <div>
                    <label class="block text-sm font-bold text-gray-700 mb-2">Status Pesanan</label>
                    <select name="status" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none">
                        <option value="all" {{ $currentStatus === 'all' ? 'selected' : '' }}>Semua Status</option>
                        <option value="pending" {{ $currentStatus === 'pending' ? 'selected' : '' }}>⏳ Menunggu</option>
                        <option value="processing" {{ $currentStatus === 'processing' ? 'selected' : '' }}>👨‍🍳 Diproses</option>
                        <option value="completed" {{ $currentStatus === 'completed' ? 'selected' : '' }}>✅ Selesai</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-bold text-gray-700 mb-2">Kantin</label>
                    <select name="canteen_id" class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none">
                        <option value="all" {{ $currentCanteen === 'all' ? 'selected' : '' }}>Semua Kantin</option>
                        @foreach($canteens as $canteen)
                            <option value="{{ $canteen->id }}" {{ $currentCanteen == $canteen->id ? 'selected' : '' }}>{{ $canteen->name }}</option>
                        @endforeach
                    </select>
                </div>
                <button type="submit" class="px-6 py-2 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 transition">
                    🔍 Filter
                </button>
                <a href="{{ route('admin.orders.index') }}" class="px-6 py-2 bg-gray-300 text-gray-800 font-bold rounded-lg hover:bg-gray-400 transition">
                    ↻ Reset
                </a>
            </form>
        </div>

        <!-- Orders Table -->
        <div class="bg-white rounded-lg shadow-md overflow-hidden">
            @if($orders->count() > 0)
                <table class="w-full">
                    <thead class="bg-gradient-to-r from-blue-600 to-blue-700 text-white">
                        <tr>
                            <th class="px-6 py-4 text-left text-sm font-bold">No. Pesanan</th>
                            <th class="px-6 py-4 text-left text-sm font-bold">Pelanggan</th>
                            <th class="px-6 py-4 text-left text-sm font-bold">Kantin</th>
                            <th class="px-6 py-4 text-left text-sm font-bold">Total</th>
                            <th class="px-6 py-4 text-left text-sm font-bold">Status</th>
                            <th class="px-6 py-4 text-left text-sm font-bold">Waktu Pesan</th>
                            <th class="px-6 py-4 text-center text-sm font-bold">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200" id="ordersTableBody">
                        @foreach($orders as $order)
                            @php
                                $items = is_string($order->items) ? json_decode($order->items, true) : $order->items;
                            @endphp
                            <tr class="hover:bg-blue-50 transition" data-order-id="{{ $order->id }}">
                                <td class="px-6 py-4 font-bold text-blue-600">{{ $order->order_number }}</td>
                                <td class="px-6 py-4">
                                    <div class="text-sm font-medium text-gray-900">{{ $order->user->name }}</div>
                                    <div class="text-xs text-gray-500">{{ $order->user->email }}</div>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="text-sm font-medium text-gray-900">{{ $order->canteen->name ?? '❌ N/A' }}</div>
                                    @if($order->canteen)
                                        <div class="text-xs text-gray-500">{{ $order->canteen->ibuKantin->name ?? 'Ibu Kantin' }}</div>
                                    @endif
                                </td>
                                <td class="px-6 py-4 font-bold text-green-600">
                                    Rp {{ number_format($order->total_amount, 0, ',', '.') }}
                                </td>
                                <td class="px-6 py-4">
                                    @if($order->status === 'pending')
                                        <span class="inline-block px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs font-bold">⏳ Menunggu</span>
                                    @elseif($order->status === 'processing')
                                        <span class="inline-block px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-bold">👨‍🍳 Diproses</span>
                                    @else
                                        <span class="inline-block px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs font-bold">✅ Selesai</span>
                                    @endif
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-700">
                                    {{ $order->created_at->format('d/m/Y H:i') }}
                                </td>
                                <td class="px-6 py-4 text-center">
                                    @php
                                        $orderData = [
                                            'id'            => $order->id,
                                            'order_number'  => $order->order_number,
                                            'customer'      => $order->user->name,
                                            'email'         => $order->user->email,
                                            'canteen'       => $order->canteen->name ?? 'N/A',
                                            'ibu_kantin'    => optional(optional($order->canteen)->ibuKantin)->name ?? '-',
                                            'items'         => $items,
                                            'total'         => $order->total_amount,
                                            'status'        => $order->status,
                                            'notes'         => $order->notes,
                                            'created_at'    => $order->created_at->format('d M Y, H:i'),
                                            'processing_at' => $order->processing_at?->format('d M Y, H:i') ?? null,
                                            'completed_at'  => $order->completed_at?->format('d M Y, H:i') ?? null,
                                        ];
                                    @endphp
                                    <button
                                        onclick="showOrderDetail(this)"
                                        data-order="{{ json_encode($orderData, JSON_HEX_QUOT | JSON_HEX_APOS) }}"
                                        class="inline-flex items-center gap-1 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-4 py-2 rounded-lg transition">
                                        <i class="fas fa-eye"></i> Lihat Detail
                                    </button>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>

                <!-- Pagination -->
                <div class="px-6 py-4 bg-gray-50 border-t">
                    {{ $orders->links() }}
                </div>
            @else
                <div class="px-6 py-12 text-center">
                    <i class="fas fa-inbox text-6xl text-gray-300 mb-4"></i>
                    <p class="text-gray-500 font-medium">Tidak ada pesanan untuk ditampilkan</p>
                </div>
            @endif
        </div>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
            <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-yellow-400">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-600 font-medium text-sm">⏳ Menunggu</p>
                        <p class="text-4xl font-black text-yellow-600">{{ \App\Models\Order::where('status', 'pending')->count() }}</p>
                    </div>
                    <i class="fas fa-hourglass-half text-5xl text-yellow-200 opacity-50"></i>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-400">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-600 font-medium text-sm">👨‍🍳 Diproses</p>
                        <p class="text-4xl font-black text-blue-600">{{ \App\Models\Order::where('status', 'processing')->count() }}</p>
                    </div>
                    <i class="fas fa-fire text-5xl text-blue-200 opacity-50"></i>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-green-400">
                <div class="flex items-center justify-between">
                    <div>
                        <p class="text-gray-600 font-medium text-sm">✅ Selesai</p>
                        <p class="text-4xl font-black text-green-600">{{ \App\Models\Order::where('status', 'completed')->count() }}</p>
                    </div>
                    <i class="fas fa-check-circle text-5xl text-green-200 opacity-50"></i>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- ===================== MODAL DETAIL PESANAN ===================== -->
<div id="orderDetailModal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/60 backdrop-blur-sm p-4">
    <div class="bg-white rounded-[30px] shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <!-- Modal Header -->
        <div class="sticky top-0 bg-gradient-to-r from-[#122C4F] to-[#1e4a78] text-white p-6 rounded-t-[30px] flex justify-between items-center">
            <div>
                <h2 class="text-xl font-black" id="modalOrderNumber">—</h2>
                <p class="text-blue-200 text-sm mt-0.5">Detail Lengkap Pesanan</p>
            </div>
            <button onclick="closeOrderModal()" class="w-9 h-9 bg-white/20 hover:bg-white/40 rounded-full flex items-center justify-center transition">
                <i class="fas fa-times"></i>
            </button>
        </div>

        <!-- Modal Body -->
        <div class="p-6 space-y-5">
            <!-- Status Badge -->
            <div class="flex items-center gap-3">
                <span class="text-sm font-bold text-gray-500">Status:</span>
                <span id="modalStatusBadge" class="px-4 py-1 rounded-full text-sm font-bold">—</span>
            </div>

            <!-- Info Pelanggan -->
            <div class="bg-blue-50 rounded-2xl p-4 space-y-2">
                <p class="text-xs font-black text-blue-400 uppercase tracking-widest mb-2">👤 Pelanggan</p>
                <div class="flex justify-between text-sm">
                    <span class="text-gray-500">Nama</span>
                    <span class="font-bold text-gray-800" id="modalCustomer">—</span>
                </div>
                <div class="flex justify-between text-sm">
                    <span class="text-gray-500">Email</span>
                    <span class="font-medium text-gray-700 text-xs" id="modalEmail">—</span>
                </div>
            </div>

            <!-- Info Kantin -->
            <div class="bg-orange-50 rounded-2xl p-4 space-y-2">
                <p class="text-xs font-black text-orange-400 uppercase tracking-widest mb-2">🏪 Kantin</p>
                <div class="flex justify-between text-sm">
                    <span class="text-gray-500">Nama Kantin</span>
                    <span class="font-bold text-gray-800" id="modalCanteen">—</span>
                </div>
                <div class="flex justify-between text-sm">
                    <span class="text-gray-500">Ibu Kantin</span>
                    <span class="font-medium text-gray-700" id="modalIbuKantin">—</span>
                </div>
            </div>

            <!-- Items -->
            <div class="bg-gray-50 rounded-2xl p-4">
                <p class="text-xs font-black text-gray-400 uppercase tracking-widest mb-3">🛒 Item Pesanan</p>
                <div id="modalItems" class="space-y-2"></div>
                <div class="border-t border-gray-200 mt-3 pt-3 flex justify-between items-center">
                    <span class="font-bold text-gray-700">Total Pembayaran</span>
                    <span class="text-xl font-black text-green-600" id="modalTotal">—</span>
                </div>
            </div>

            <!-- Catatan -->
            <div id="modalNotesSection" class="hidden bg-yellow-50 rounded-2xl p-4">
                <p class="text-xs font-black text-yellow-500 uppercase tracking-widest mb-2">📝 Catatan</p>
                <p class="text-sm text-gray-700" id="modalNotes">—</p>
            </div>

            <!-- Waktu -->
            <div class="bg-purple-50 rounded-2xl p-4 space-y-2">
                <p class="text-xs font-black text-purple-400 uppercase tracking-widest mb-2">🕐 Timeline</p>
                <div class="flex justify-between text-sm">
                    <span class="text-gray-500">Dipesan</span>
                    <span class="font-medium text-gray-700" id="modalCreatedAt">—</span>
                </div>
                <div class="flex justify-between text-sm" id="modalProcessingRow">
                    <span class="text-gray-500">Mulai Diproses</span>
                    <span class="font-medium text-gray-700" id="modalProcessingAt">—</span>
                </div>
                <div class="flex justify-between text-sm" id="modalCompletedRow">
                    <span class="text-gray-500">Selesai</span>
                    <span class="font-medium text-gray-700" id="modalCompletedAt">—</span>
                </div>
            </div>
        </div>

        <!-- Modal Footer -->
        <div class="px-6 pb-6">
            <button onclick="closeOrderModal()" class="w-full bg-[#122C4F] hover:bg-[#1e4a78] text-white font-bold py-3 rounded-2xl transition">
                Tutup
            </button>
        </div>
    </div>
</div>

<script>
function showOrderDetail(btn) {
    const order = JSON.parse(btn.getAttribute('data-order'));
    // Isi semua field modal
    document.getElementById('modalOrderNumber').textContent = order.order_number;
    document.getElementById('modalCustomer').textContent   = order.customer;
    document.getElementById('modalEmail').textContent      = order.email;
    document.getElementById('modalCanteen').textContent    = order.canteen;
    document.getElementById('modalIbuKantin').textContent  = order.ibu_kantin;
    document.getElementById('modalCreatedAt').textContent  = order.created_at;
    document.getElementById('modalProcessingAt').textContent = order.processing_at ?? '—';
    document.getElementById('modalCompletedAt').textContent  = order.completed_at  ?? '—';

    // Total
    document.getElementById('modalTotal').textContent =
        'Rp ' + parseInt(order.total).toLocaleString('id-ID');

    // Status badge
    const badge = document.getElementById('modalStatusBadge');
    const statusMap = {
        pending:    { label: '⏳ Menunggu',  cls: 'bg-yellow-100 text-yellow-800' },
        processing: { label: '👨‍🍳 Diproses', cls: 'bg-blue-100 text-blue-800' },
        completed:  { label: '✅ Selesai',   cls: 'bg-green-100 text-green-800' },
        cancelled:  { label: '❌ Dibatalkan',cls: 'bg-red-100 text-red-800' },
    };
    const s = statusMap[order.status] ?? { label: order.status, cls: 'bg-gray-100 text-gray-700' };
    badge.textContent = s.label;
    badge.className   = 'px-4 py-1 rounded-full text-sm font-bold ' + s.cls;

    // Items
    const itemsContainer = document.getElementById('modalItems');
    itemsContainer.innerHTML = '';
    if (order.items && order.items.length > 0) {
        order.items.forEach(item => {
            const qty  = item.qty ?? item.quantity ?? 1;
            const price = item.price ?? 0;
            const subtotal = qty * price;
            itemsContainer.innerHTML += `
                <div class="flex justify-between items-center text-sm py-1 border-b border-gray-100 last:border-0">
                    <span class="text-gray-700 font-medium">${item.name} <span class="text-gray-400">×${qty}</span></span>
                    <span class="font-bold text-gray-800">Rp ${subtotal.toLocaleString('id-ID')}</span>
                </div>`;
        });
    } else {
        itemsContainer.innerHTML = '<p class="text-gray-400 text-sm">Data item tidak tersedia</p>';
    }

    // Catatan
    if (order.notes) {
        document.getElementById('modalNotes').textContent = order.notes;
        document.getElementById('modalNotesSection').classList.remove('hidden');
    } else {
        document.getElementById('modalNotesSection').classList.add('hidden');
    }

    // Tampilkan modal
    const modal = document.getElementById('orderDetailModal');
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}

function closeOrderModal() {
    const modal = document.getElementById('orderDetailModal');
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}

// Tutup kalau klik backdrop
document.getElementById('orderDetailModal').addEventListener('click', function(e) {
    if (e.target === this) closeOrderModal();
});
</script>
@endsection
