@extends('layouts.app')

@section('content')
<div class="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-8 px-4 sm:px-6 lg:px-8">
    <div class="max-w-7xl mx-auto">

        <!-- Header + Kembali -->
        <div class="mb-8 flex justify-between items-start">
            <div>
                <a href="{{ route('admin.dashboard') }}" class="inline-flex items-center gap-2 text-gray-600 hover:text-[#122C4F] font-bold mb-3 transition">
                    <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
                </a>
                <h1 class="text-4xl font-black text-gray-900 mb-2">🏪 Kelola Kantin</h1>
                <p class="text-gray-600 font-medium">Manajemen semua kantin Tel-U dan ibu kantin</p>
            </div>
            <button onclick="openAddCanteenModal()"
                class="px-6 py-3 bg-green-600 text-white font-bold rounded-lg hover:bg-green-700 transition flex items-center gap-2 mt-8">
                <i class="fas fa-plus"></i> Tambah Kantin
            </button>
        </div>

        <!-- Canteens Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            @forelse($canteens as $canteen)
                <div class="bg-white rounded-lg shadow-md hover:shadow-lg transition overflow-hidden border-t-4 border-blue-600">
                    <div class="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-6">
                        <h2 class="text-2xl font-bold mb-1">{{ $canteen->name }}</h2>
                        <p class="text-blue-100 text-sm">🏢 Kantin Telkom University</p>
                    </div>
                    <div class="p-6 space-y-4">
                        <div class="flex items-center gap-3 pb-4 border-b">
                            <div class="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                                {{ strtoupper(substr($canteen->ibuKantin->name ?? 'IK', 0, 1)) }}
                            </div>
                            <div>
                                <p class="text-xs text-gray-500 font-medium">IBU KANTIN</p>
                                <p class="text-sm font-bold text-gray-900">{{ $canteen->ibuKantin->name ?? 'N/A' }}</p>
                                <p class="text-xs text-gray-500">{{ $canteen->ibuKantin->email ?? 'N/A' }}</p>
                            </div>
                        </div>
                        <div class="grid grid-cols-3 gap-4">
                            <div class="text-center p-3 bg-gray-50 rounded-lg">
                                <div class="text-2xl font-black text-blue-600">{{ $canteen->orders_count }}</div>
                                <div class="text-xs font-bold text-gray-600 uppercase tracking-wider">Pesanan</div>
                            </div>
                            <div class="text-center p-3 bg-gray-50 rounded-lg">
                                <div class="text-2xl font-black text-green-600">{{ $canteen->menus_count }}</div>
                                <div class="text-xs font-bold text-gray-600 uppercase tracking-wider">Menu</div>
                            </div>
                            <div class="text-center p-3 bg-gray-50 rounded-lg">
                                <div class="text-2xl font-black text-purple-600">{{ $canteen->vouchers_count }}</div>
                                <div class="text-xs font-bold text-gray-600 uppercase tracking-wider">Voucher</div>
                            </div>
                        </div>
                        @if($canteen->address)
                            <div class="text-sm text-gray-700 p-3 bg-gray-50 rounded-lg">
                                <p class="font-bold mb-1">📍 Lokasi:</p>
                                <p>{{ $canteen->address }}</p>
                            </div>
                        @endif
                        <div class="flex items-center justify-between pt-4 border-t">
                            <span class="inline-block px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs font-bold">✅ Aktif</span>
                            <div class="flex gap-2">
                                <button onclick="openEditCanteenModal({{ $canteen->id }}, '{{ addslashes($canteen->name) }}')"
                                    class="text-blue-600 hover:text-blue-800 font-bold text-sm transition">✏️ Edit</button>
                                <button onclick="openDetailModal({{ $canteen->id }}, '{{ addslashes($canteen->name) }}', '{{ addslashes($canteen->ibuKantin->name ?? 'N/A') }}', {{ $canteen->orders_count }}, {{ $canteen->menus_count }}, {{ $canteen->vouchers_count }})"
                                    class="text-gray-600 hover:text-gray-800 font-bold text-sm transition">👁️ Detail</button>
                            </div>
                        </div>
                    </div>
                </div>
            @empty
                <div class="col-span-full text-center py-12 bg-white rounded-lg shadow-sm">
                    <i class="fas fa-building text-6xl text-gray-300 mb-4"></i>
                    <p class="text-gray-500 font-medium">Belum ada kantin terdaftar</p>
                    <button onclick="openAddCanteenModal()" class="mt-4 px-6 py-2 bg-green-600 text-white font-bold rounded-lg hover:bg-green-700 transition">
                        + Tambah Kantin Pertama
                    </button>
                </div>
            @endforelse
        </div>

        <!-- Summary Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mt-12">
            <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-600">
                <p class="text-gray-600 font-medium text-sm">Total Kantin</p>
                <p class="text-4xl font-black text-blue-600">{{ $canteens->count() }}</p>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-green-600">
                <p class="text-gray-600 font-medium text-sm">Total Menu</p>
                <p class="text-4xl font-black text-green-600">{{ $canteens->sum('menus_count') }}</p>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-purple-600">
                <p class="text-gray-600 font-medium text-sm">Total Voucher</p>
                <p class="text-4xl font-black text-purple-600">{{ $canteens->sum('vouchers_count') }}</p>
            </div>
            <div class="bg-white rounded-lg shadow-md p-6 border-l-4 border-orange-600">
                <p class="text-gray-600 font-medium text-sm">Total Pesanan</p>
                <p class="text-4xl font-black text-orange-600">{{ $canteens->sum('orders_count') }}</p>
            </div>
        </div>

        <!-- Table -->
        <div class="bg-white rounded-lg shadow-md overflow-hidden mt-12">
            <table class="w-full">
                <thead class="bg-gradient-to-r from-blue-600 to-blue-700 text-white">
                    <tr>
                        <th class="px-6 py-4 text-left text-sm font-bold">Kantin</th>
                        <th class="px-6 py-4 text-left text-sm font-bold">Ibu Kantin</th>
                        <th class="px-6 py-4 text-center text-sm font-bold">Pesanan</th>
                        <th class="px-6 py-4 text-center text-sm font-bold">Menu</th>
                        <th class="px-6 py-4 text-center text-sm font-bold">Voucher</th>
                        <th class="px-6 py-4 text-center text-sm font-bold">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    @foreach($canteens as $canteen)
                        <tr class="hover:bg-blue-50 transition">
                            <td class="px-6 py-4 font-bold text-blue-600">{{ $canteen->name }}</td>
                            <td class="px-6 py-4">
                                <div class="text-sm font-medium text-gray-900">{{ $canteen->ibuKantin->name ?? '-' }}</div>
                                <div class="text-xs text-gray-500">{{ $canteen->ibuKantin->email ?? '-' }}</div>
                            </td>
                            <td class="px-6 py-4 text-center"><span class="inline-block px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-bold">{{ $canteen->orders_count }}</span></td>
                            <td class="px-6 py-4 text-center"><span class="inline-block px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-bold">{{ $canteen->menus_count }}</span></td>
                            <td class="px-6 py-4 text-center"><span class="inline-block px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-bold">{{ $canteen->vouchers_count }}</span></td>
                            <td class="px-6 py-4 text-center"><span class="inline-block px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs font-bold">✅ Aktif</span></td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

    </div>
</div>

<!-- ============== MODAL TAMBAH KANTIN ============== -->
<div id="addCanteenModal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/60 backdrop-blur-sm p-4">
    <div class="bg-white rounded-[30px] shadow-2xl w-full max-w-md">
        <div class="bg-gradient-to-r from-green-500 to-green-700 text-white p-6 rounded-t-[30px] flex justify-between items-center">
            <div>
                <h2 class="text-xl font-black">➕ Tambah Kantin Baru</h2>
                <p class="text-green-100 text-sm mt-0.5">Daftarkan kantin baru ke sistem</p>
            </div>
            <button onclick="closeAddCanteenModal()" class="w-9 h-9 bg-white/20 hover:bg-white/40 rounded-full flex items-center justify-center transition">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="p-6 space-y-4">
            <div class="bg-yellow-50 border border-yellow-200 rounded-xl p-4 text-sm text-yellow-800">
                <i class="fas fa-info-circle mr-2"></i>
                <strong>Catatan Developer:</strong> Fitur tambah kantin memerlukan integrasi backend.
                Saat ini data bisa ditambahkan langsung via database atau seeder.
            </div>
            <div>
                <label class="block text-sm font-bold text-gray-700 mb-2">Nama Kantin</label>
                <input type="text" id="newCanteenName" placeholder="Contoh: Kantin Gedung B"
                    class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-400 outline-none">
            </div>
            <div>
                <label class="block text-sm font-bold text-gray-700 mb-2">Email Ibu Kantin</label>
                <input type="email" id="newCanteenEmail" placeholder="ibukantin@example.com"
                    class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-400 outline-none">
            </div>
            <div>
                <label class="block text-sm font-bold text-gray-700 mb-2">Lokasi / Gedung</label>
                <select id="newCanteenLocation" class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-green-400 outline-none">
                    <option value="">-- Pilih Lokasi --</option>
                    <option>Halaman Utama Kampus</option>
                    <option>Gedung A – Lantai 1</option>
                    <option>Gedung B – Lantai 1</option>
                    <option>Gedung C – Lantai Dasar</option>
                    <option>Gedung D – Basement</option>
                    <option>Area Parkir Selatan</option>
                    <option>Ruang Makan Mahasiswa</option>
                    <option>Kelas TK – Lantai 2</option>
                    <option>Lab Informatika – Lantai 3</option>
                    <option>Perpustakaan – Lantai 1</option>
                </select>
            </div>
            <div class="flex gap-3 pt-2">
                <button onclick="closeAddCanteenModal()"
                    class="flex-1 py-3 bg-gray-100 text-gray-700 font-bold rounded-2xl hover:bg-gray-200 transition">
                    Batal
                </button>
                <button onclick="submitAddCanteen()"
                    class="flex-1 py-3 bg-green-600 text-white font-bold rounded-2xl hover:bg-green-700 transition">
                    💾 Simpan
                </button>
            </div>
        </div>
    </div>
</div>

<!-- ============== MODAL EDIT KANTIN ============== -->
<div id="editCanteenModal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/60 backdrop-blur-sm p-4">
    <div class="bg-white rounded-[30px] shadow-2xl w-full max-w-md">
        <div class="bg-gradient-to-r from-blue-500 to-blue-700 text-white p-6 rounded-t-[30px] flex justify-between items-center">
            <h2 class="text-xl font-black">✏️ Edit Kantin</h2>
            <button onclick="closeEditCanteenModal()" class="w-9 h-9 bg-white/20 hover:bg-white/40 rounded-full flex items-center justify-center transition">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="p-6 space-y-4">
            <div class="bg-blue-50 border border-blue-200 rounded-xl p-4 text-sm text-blue-800">
                <i class="fas fa-info-circle mr-2"></i>Editing kantin ID: <strong id="editCanteenId">—</strong>
            </div>
            <div>
                <label class="block text-sm font-bold text-gray-700 mb-2">Nama Kantin</label>
                <input type="text" id="editCanteenName"
                    class="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-400 outline-none">
            </div>
            <div class="flex gap-3 pt-2">
                <button onclick="closeEditCanteenModal()"
                    class="flex-1 py-3 bg-gray-100 text-gray-700 font-bold rounded-2xl hover:bg-gray-200 transition">
                    Batal
                </button>
                <button onclick="submitEditCanteen()"
                    class="flex-1 py-3 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition">
                    💾 Update
                </button>
            </div>
        </div>
    </div>
</div>

<!-- ============== MODAL DETAIL KANTIN ============== -->
<div id="detailCanteenModal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/60 backdrop-blur-sm p-4">
    <div class="bg-white rounded-[30px] shadow-2xl w-full max-w-md">
        <div class="bg-gradient-to-r from-[#122C4F] to-[#1e4a78] text-white p-6 rounded-t-[30px] flex justify-between items-center">
            <h2 class="text-xl font-black" id="detailCanteenTitle">—</h2>
            <button onclick="closeDetailModal()" class="w-9 h-9 bg-white/20 hover:bg-white/40 rounded-full flex items-center justify-center transition">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="p-6 space-y-4">
            <div class="bg-gray-50 rounded-2xl p-4 space-y-3">
                <div class="flex justify-between text-sm">
                    <span class="text-gray-500 font-medium">Ibu Kantin</span>
                    <span class="font-bold text-gray-800" id="detailIbuKantin">—</span>
                </div>
                <div class="flex justify-between text-sm">
                    <span class="text-gray-500 font-medium">Total Pesanan</span>
                    <span class="font-bold text-blue-600" id="detailOrders">—</span>
                </div>
                <div class="flex justify-between text-sm">
                    <span class="text-gray-500 font-medium">Total Menu</span>
                    <span class="font-bold text-green-600" id="detailMenus">—</span>
                </div>
                <div class="flex justify-between text-sm">
                    <span class="text-gray-500 font-medium">Total Voucher</span>
                    <span class="font-bold text-purple-600" id="detailVouchers">—</span>
                </div>
            </div>
            <button onclick="closeDetailModal()" class="w-full py-3 bg-[#122C4F] text-white font-bold rounded-2xl hover:bg-[#1e4a78] transition">
                Tutup
            </button>
        </div>
    </div>
</div>

<script>
// ---- Add Canteen ----
function openAddCanteenModal() {
    document.getElementById('addCanteenModal').classList.remove('hidden');
    document.getElementById('addCanteenModal').classList.add('flex');
}
function closeAddCanteenModal() {
    document.getElementById('addCanteenModal').classList.add('hidden');
    document.getElementById('addCanteenModal').classList.remove('flex');
}
function submitAddCanteen() {
    const name = document.getElementById('newCanteenName').value.trim();
    const email = document.getElementById('newCanteenEmail').value.trim();
    const loc   = document.getElementById('newCanteenLocation').value;
    if (!name || !email) { alert('Nama dan email wajib diisi!'); return; }
    alert(`✅ Data Kantin "${name}" berhasil dicatat!\n\n📧 Email: ${email}\n📍 Lokasi: ${loc || 'Belum ditentukan'}\n\n⚠️ Simpan ke database memerlukan integrasi route POST /admin/canteens. Hubungi developer untuk aktivasi penuh.`);
    closeAddCanteenModal();
}

// ---- Edit Canteen ----
function openEditCanteenModal(id, name) {
    document.getElementById('editCanteenId').textContent = id;
    document.getElementById('editCanteenName').value = name;
    document.getElementById('editCanteenModal').classList.remove('hidden');
    document.getElementById('editCanteenModal').classList.add('flex');
}
function closeEditCanteenModal() {
    document.getElementById('editCanteenModal').classList.add('hidden');
    document.getElementById('editCanteenModal').classList.remove('flex');
}
function submitEditCanteen() {
    const name = document.getElementById('editCanteenName').value.trim();
    if (!name) { alert('Nama kantin tidak boleh kosong!'); return; }
    alert(`✅ Nama kantin berhasil diperbarui menjadi "${name}"!\n\n⚠️ Simpan ke database memerlukan integrasi route PUT /admin/canteens/{id}. Hubungi developer untuk aktivasi penuh.`);
    closeEditCanteenModal();
}

// ---- Detail Modal ----
function openDetailModal(id, name, ibuKantin, orders, menus, vouchers) {
    document.getElementById('detailCanteenTitle').textContent = '🏪 ' + name;
    document.getElementById('detailIbuKantin').textContent = ibuKantin;
    document.getElementById('detailOrders').textContent   = orders + ' pesanan';
    document.getElementById('detailMenus').textContent    = menus  + ' menu';
    document.getElementById('detailVouchers').textContent = vouchers + ' voucher';
    document.getElementById('detailCanteenModal').classList.remove('hidden');
    document.getElementById('detailCanteenModal').classList.add('flex');
}
function closeDetailModal() {
    document.getElementById('detailCanteenModal').classList.add('hidden');
    document.getElementById('detailCanteenModal').classList.remove('flex');
}

// Backdrop klik
['addCanteenModal','editCanteenModal','detailCanteenModal'].forEach(id => {
    document.getElementById(id).addEventListener('click', function(e) {
        if (e.target === this) this.classList.add('hidden'), this.classList.remove('flex');
    });
});
</script>
@endsection
