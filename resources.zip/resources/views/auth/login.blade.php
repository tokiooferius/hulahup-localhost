<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Masuk - Hulahup</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { font-family: 'Plus Jakarta Sans', sans-serif; }

        .left-panel {
            background: linear-gradient(155deg, #1a3a5c 0%, #2d6a8f 45%, #3a7fa8 100%);
        }

        .blob {
            border-radius: 30% 70% 70% 30% / 30% 30% 70% 70%;
            animation: blobMorph 8s ease-in-out infinite;
        }
        .blob2 { animation-delay: -4s; border-radius: 70% 30% 30% 70% / 70% 70% 30% 30%; }
        @keyframes blobMorph {
            0%,100% { border-radius: 30% 70% 70% 30% / 30% 30% 70% 70%; }
            33%      { border-radius: 70% 30% 30% 70% / 70% 70% 30% 30%; }
            66%      { border-radius: 50% 50% 30% 70% / 40% 60% 40% 60%; }
        }

        .dots-bg {
            background-image: radial-gradient(circle, rgba(255,255,255,0.12) 1px, transparent 1px);
            background-size: 26px 26px;
        }

        /* Floating cards */
        .float-card { animation: floatY 4s ease-in-out infinite; }
        .float-card:nth-child(2) { animation-delay: -1.4s; }
        .float-card:nth-child(3) { animation-delay: -2.8s; }
        @keyframes floatY {
            0%,100% { transform: translateY(0); }
            50%      { transform: translateY(-9px); }
        }

        /* Pulse ring */
        @keyframes pulseRing {
            0%   { transform: scale(1); opacity:.5; }
            100% { transform: scale(1.6); opacity:0; }
        }
        .pulse { animation: pulseRing 2.2s ease-out infinite; }

        /* Input */
        .input-field {
            border: 2px solid #e5e7eb;
            transition: all .25s ease;
        }
        .input-field:focus {
            border-color: #2d6a8f;
            box-shadow: 0 0 0 4px rgba(45,106,143,.12);
            outline: none;
            background: #fff;
        }

        /* Button ripple */
        .btn-primary { position: relative; overflow: hidden; }
        .btn-primary::after {
            content:''; position:absolute; inset:0;
            background: radial-gradient(circle, rgba(255,255,255,.25) 0%, transparent 70%);
            opacity:0; transition: opacity .3s;
        }
        .btn-primary:hover::after { opacity:1; }

        /* Marquee */
        @keyframes marquee { from { transform: translateX(0); } to { transform: translateX(-50%); } }
        .marquee-track { animation: marquee 18s linear infinite; }
    </style>
</head>
<body class="bg-slate-100 min-h-screen flex">

    <!-- LEFT — Visual Panel -->
    <div class="hidden lg:flex w-1/2 left-panel flex-col relative overflow-hidden min-h-screen">
        <div class="dots-bg absolute inset-0"></div>
        <div class="blob blob2 absolute w-80 h-80 bg-white/5 -top-16 -left-16"></div>
        <div class="blob absolute w-64 h-64 bg-[#EAD8B1]/10 bottom-10 -right-10" style="animation-delay:-3s"></div>

        <!-- Top nav -->
        <div class="relative z-10 px-10 pt-8">
            <div class="flex items-center gap-2">
                <span class="text-2xl font-black italic text-white">Hulahup.</span>
                <span class="text-[10px] bg-white/15 text-white/80 px-2 py-0.5 rounded-full font-bold uppercase tracking-widest border border-white/20">TEL-U</span>
            </div>
        </div>

        <!-- Center content -->
        <div class="relative z-10 flex-1 flex flex-col items-center justify-center px-10 py-8">

            <!-- Logo pulse -->
            <div class="relative mb-8">
                <div class="pulse absolute inset-0 rounded-[28px] border-2 border-white/30"></div>
                <div class="bg-white/15 border border-white/20 rounded-[28px] px-8 py-5 backdrop-blur-sm text-center shadow-2xl">
                    <h1 class="text-5xl font-black italic text-white tracking-tighter">Hulahup.</h1>
                    <p class="text-white/50 text-[10px] font-bold tracking-widest mt-1 uppercase">Kantin Tel-U Purwokerto</p>
                </div>
            </div>

            <!-- Floating food cards -->
            <div class="relative w-full max-w-xs h-40 mb-8">
                <div class="float-card absolute left-0 top-0 bg-white/15 border border-white/20 rounded-2xl px-4 py-3 flex items-center gap-3 shadow-xl backdrop-blur-sm">
                    <span class="text-2xl">🍜</span>
                    <div><p class="text-white font-bold text-sm">Bakso Malang</p><p class="text-white/50 text-xs">Rp 15.000</p></div>
                </div>
                <div class="float-card absolute right-0 top-5 bg-white/15 border border-white/20 rounded-2xl px-4 py-3 flex items-center gap-3 shadow-xl backdrop-blur-sm">
                    <span class="text-2xl">🍗</span>
                    <div><p class="text-white font-bold text-sm">Ayam Goreng</p><p class="text-white/50 text-xs">Rp 16.000</p></div>
                </div>
                <div class="float-card absolute left-6 bottom-0 bg-white/15 border border-white/20 rounded-2xl px-4 py-3 flex items-center gap-3 shadow-xl backdrop-blur-sm">
                    <span class="text-2xl">☕</span>
                    <div><p class="text-white font-bold text-sm">Ice Americano</p><p class="text-white/50 text-xs">Rp 12.000</p></div>
                </div>
            </div>

            <!-- Stats row -->
            <div class="flex gap-4 w-full max-w-xs">
                <div class="flex-1 bg-white/10 border border-white/15 rounded-2xl p-3 text-center">
                    <p class="text-white font-black text-xl">3</p>
                    <p class="text-white/50 text-[10px] font-semibold uppercase tracking-wider">Kantin</p>
                </div>
                <div class="flex-1 bg-white/10 border border-white/15 rounded-2xl p-3 text-center">
                    <p class="text-white font-black text-xl">50+</p>
                    <p class="text-white/50 text-[10px] font-semibold uppercase tracking-wider">Menu</p>
                </div>
                <div class="flex-1 bg-white/10 border border-white/15 rounded-2xl p-3 text-center">
                    <p class="text-white font-black text-xl">⚡</p>
                    <p class="text-white/50 text-[10px] font-semibold uppercase tracking-wider">Realtime</p>
                </div>
            </div>
        </div>

        <!-- Bottom marquee -->
        <div class="relative z-10 pb-6 overflow-hidden">
            <div class="flex whitespace-nowrap marquee-track">
                @foreach(range(1,2) as $_)
                    <span class="text-white/20 text-xs font-bold uppercase tracking-widest px-4">🍜 Pesan Sekarang</span>
                    <span class="text-white/20 text-xs font-bold uppercase tracking-widest px-4">⚡ Tanpa Antri</span>
                    <span class="text-white/20 text-xs font-bold uppercase tracking-widest px-4">🔒 Bayar Aman</span>
                    <span class="text-white/20 text-xs font-bold uppercase tracking-widest px-4">🎟️ Pakai Voucher</span>
                    <span class="text-white/20 text-xs font-bold uppercase tracking-widest px-4">🏪 3 Kantin Tersedia</span>
                    <span class="text-white/20 text-xs font-bold uppercase tracking-widest px-4">💳 QRIS & TyU-Pay</span>
                @endforeach
            </div>
        </div>
    </div>

    <!-- RIGHT — Form Panel -->
    <div class="w-full lg:w-1/2 bg-white flex flex-col justify-center min-h-screen overflow-y-auto px-10 py-12">

        <!-- Mobile logo -->
        <div class="lg:hidden mb-8 text-center">
            <span class="text-3xl font-black italic text-[#1a3a5c]">Hulahup.</span>
        </div>

        <div class="max-w-sm mx-auto w-full">

            <div class="mb-8">
                <h2 class="text-3xl font-black text-slate-800 tracking-tight">Selamat datang! 👋</h2>
                <p class="text-slate-400 mt-1.5 text-sm font-medium">Masuk ke akun Hulahup kamu.</p>
            </div>

            @if(session('success'))
                <div class="bg-green-50 border border-green-200 text-green-700 rounded-2xl p-4 mb-5 flex items-center gap-3">
                    <i class="fas fa-check-circle text-green-500"></i>
                    <p class="text-sm font-bold">{{ session('success') }}</p>
                </div>
            @endif
            @if(session('error'))
                <div class="bg-red-50 border border-red-200 text-red-700 rounded-2xl p-4 mb-5 flex items-center gap-3">
                    <i class="fas fa-exclamation-circle text-red-500"></i>
                    <p class="text-sm font-bold">{{ session('error') }}</p>
                </div>
            @endif

            <form action="/login" method="POST" class="space-y-4" id="loginForm">
                @csrf

                <!-- Username -->
                <div>
                    <label class="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5">Username</label>
                    <div class="relative">
                        <i class="fas fa-at absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 text-sm"></i>
                        <input type="text" name="username" id="usernameInput"
                            placeholder="Masukkan username kamu"
                            class="input-field w-full pl-11 pr-4 py-3.5 rounded-2xl text-sm bg-slate-50"
                            value="{{ old('username') }}" required autofocus>
                    </div>
                </div>

                <!-- Password -->
                <div>
                    <div class="flex justify-between items-center mb-1.5">
                        <label class="block text-xs font-bold text-slate-500 uppercase tracking-widest">Password</label>
                        <a href="#" class="text-xs font-bold text-[#2d6a8f] hover:underline">Lupa Password?</a>
                    </div>
                    <div class="relative">
                        <i class="fas fa-lock absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 text-sm"></i>
                        <input type="password" name="password" id="passInput"
                            placeholder="••••••••"
                            class="input-field w-full pl-11 pr-12 py-3.5 rounded-2xl text-sm bg-slate-50" required>
                        <button type="button" onclick="togglePass()"
                            class="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-600 transition">
                            <i class="fas fa-eye text-sm" id="eyeIcon"></i>
                        </button>
                    </div>
                </div>

                <!-- Remember me -->
                <label class="flex items-center gap-3 cursor-pointer select-none">
                    <div class="relative">
                        <input type="checkbox" name="remember" class="sr-only peer" id="rememberCb">
                        <div class="w-5 h-5 rounded-md border-2 border-slate-200 peer-checked:bg-[#2d6a8f] peer-checked:border-[#2d6a8f] transition flex items-center justify-center" id="rememberBox">
                            <i class="fas fa-check text-white text-[10px] opacity-0 peer-checked:opacity-100" id="rememberCheck"></i>
                        </div>
                    </div>
                    <span class="text-sm text-slate-500 font-medium">Ingat saya selama 30 hari</span>
                </label>

                <!-- Submit -->
                <button type="submit" id="submitBtn"
                    class="btn-primary w-full bg-gradient-to-r from-[#1a3a5c] to-[#2d6a8f] text-white font-black py-4 rounded-2xl shadow-lg shadow-blue-900/20 hover:shadow-xl hover:scale-[1.01] active:scale-95 transition-all uppercase tracking-widest text-sm flex items-center justify-center gap-2 mt-2">
                    <i class="fas fa-sign-in-alt"></i>
                    Masuk Sekarang
                </button>

                <!-- Divider -->
                <div class="flex items-center gap-3 my-1">
                    <div class="flex-1 h-px bg-slate-100"></div>
                    <span class="text-xs text-slate-300 font-bold uppercase tracking-wider">atau</span>
                    <div class="flex-1 h-px bg-slate-100"></div>
                </div>

                <!-- SSO Button -->
                <button type="button"
                    onclick="alert('🚧 Login SSO Tel-U sedang dalam pengembangan.\nSilakan gunakan login biasa untuk saat ini.')"
                    class="w-full bg-slate-50 border-2 border-slate-100 hover:border-[#2d6a8f] hover:bg-blue-50 py-3.5 rounded-2xl font-bold flex items-center justify-center gap-3 transition-all text-slate-600 text-sm group">
                    <div class="w-7 h-7 bg-white rounded-lg shadow-sm flex items-center justify-center">
                        <img src="https://www.svgrepo.com/show/355037/google.svg" class="w-4 h-4">
                    </div>
                    Login dengan SSO Tel-U
                    <span class="text-[10px] bg-yellow-100 text-yellow-600 px-2 py-0.5 rounded-full font-black border border-yellow-200">SOON</span>
                </button>
            </form>

            <!-- Daftar section -->
            <div class="mt-8 pt-6 border-t border-slate-100">
                <p class="text-center text-sm text-slate-400 font-medium mb-4">Belum punya akun?</p>
                <div class="grid grid-cols-2 gap-3">
                    <!-- Daftar Umum -->
                    <a href="/signup?type=umum"
                        class="group flex flex-col items-center gap-2 p-4 rounded-2xl border-2 border-slate-100 hover:border-[#2d6a8f] hover:bg-blue-50 transition-all text-center cursor-pointer">
                        <div class="w-10 h-10 bg-slate-100 group-hover:bg-[#2d6a8f] rounded-xl flex items-center justify-center transition-all">
                            <i class="fas fa-user text-slate-500 group-hover:text-white text-sm transition-all"></i>
                        </div>
                        <div>
                            <p class="font-bold text-slate-700 text-sm group-hover:text-[#1a3a5c]">Daftar Umum</p>
                            <p class="text-[10px] text-slate-400">Untuk semua orang</p>
                        </div>
                    </a>
                    <!-- Daftar Mahasiswa -->
                    <a href="/signup?type=mahasiswa"
                        class="group flex flex-col items-center gap-2 p-4 rounded-2xl border-2 border-slate-100 hover:border-[#2d6a8f] hover:bg-blue-50 transition-all text-center cursor-pointer">
                        <div class="w-10 h-10 bg-slate-100 group-hover:bg-[#2d6a8f] rounded-xl flex items-center justify-center transition-all">
                            <i class="fas fa-graduation-cap text-slate-500 group-hover:text-white text-sm transition-all"></i>
                        </div>
                        <div>
                            <p class="font-bold text-slate-700 text-sm group-hover:text-[#1a3a5c]">Mahasiswa Tel-U</p>
                            <p class="text-[10px] text-slate-400">Pakai NIM kamu</p>
                        </div>
                    </a>
                </div>
            </div>

        </div>
    </div>

</body>
<script>
    function togglePass() {
        const input = document.getElementById('passInput');
        const icon  = document.getElementById('eyeIcon');
        if (input.type === 'password') {
            input.type = 'text';
            icon.className = 'fas fa-eye-slash text-sm';
        } else {
            input.type = 'password';
            icon.className = 'fas fa-eye text-sm';
        }
    }

    // Checkbox visual
    document.getElementById('rememberCb').addEventListener('change', function() {
        document.getElementById('rememberCheck').style.opacity = this.checked ? '1' : '0';
    });

    // Submit loading state
    document.getElementById('loginForm').addEventListener('submit', function() {
        const btn = document.getElementById('submitBtn');
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Memverifikasi...';
        btn.disabled = true;
    });
</script>
</html>
